
public class main {

	public static void main(String[] args) {
		writer a = new writer();
		a.read_txt();
		a.write_txt();

	}

}
